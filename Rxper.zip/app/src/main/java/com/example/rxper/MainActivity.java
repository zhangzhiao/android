package com.example.rxper;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.os.Bundle;
import android.widget.Toast;

import com.tbruyelle.rxpermissions2.Permission;
import com.tbruyelle.rxpermissions2.RxPermissions;

import io.reactivex.functions.Consumer;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getPermissions();
    }
    private void getPermissions(){
        RxPermissions rxPermissions =new RxPermissions(MainActivity.this);
        rxPermissions.requestEach(Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.CAMERA)
                .subscribe(new Consumer<Permission>() {
                    @Override
                    public void accept(Permission permission) throws Exception {
                        if(permission.granted){
                            Toast.makeText(getApplicationContext(),"成功获取权限",Toast.LENGTH_SHORT).show();
                        }else if(permission.shouldShowRequestPermissionRationale){
                           Toast.makeText(getApplicationContext(),"您拒绝了部分权限，请在下次启动时允许",Toast.LENGTH_SHORT).show();
                         }else if(!permission.shouldShowRequestPermissionRationale){
                            Toast.makeText(getApplicationContext(),"您拒绝了部分权限，Application  Error",Toast.LENGTH_SHORT).show();

                        }
                    }
                });
    }
}
